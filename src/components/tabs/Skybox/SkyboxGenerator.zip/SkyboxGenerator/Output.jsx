/**
 * SkyboxGenerator_Output.jsx — Sektion 05: Output
 *
 * TAB-CONTRACT §4: Rein präsentational — keine Hooks, kein IPC, kein State.
 * Bündelt: Lua-Vorschau, Export-Optionen, Generate-Button, Summary-Badges.
 *
 * Props (alle aus outputProps im Parent):
 *   mapName, mapsFolderPath
 *   exportRawScmskybox, setExportRawScmskybox
 *   generateReadme, setGenerateReadme
 *   onExportScmskybox, onInjectSkybox
 *   previewJson       — live berechneter Lua-/JSON-String (readonly)
 *   planets           — Array, für Summary
 *   cirrusLayers      — Array, für Summary
 *   numStars          — String, für Summary
 *   stParsedUvs       — Array (parsed UV rows), für Summary
 */
import React from 'react';
import { OutputChecklist } from '../../../Shared/Ui/EntityPanel/EntityPanel.jsx';

// ── Hilfsfunktion: ersten N Zeichen des Previews kürzen ──────────
const MAX_PREVIEW = 2800;

const Output = ({
  mapName,
  mapsFolderPath,
  exportRawScmskybox,
  setExportRawScmskybox,
  generateReadme,
  setGenerateReadme,
  onExportScmskybox,
  onInjectSkybox,
  previewJson = '',
  planets = [],
  cirrusLayers = [],
  numStars = '0',
  stParsedUvs = [],
}) => {
  const ready = !!(mapName?.trim() && mapsFolderPath?.trim());
  const previewTrunc = previewJson.length > MAX_PREVIEW
    ? previewJson.slice(0, MAX_PREVIEW) + '\n  … (truncated)'
    : previewJson;

  return (
    <div className="ctrl-col">

      {/* ── Summary ─────────────────────────────────────────────── */}
      <div className="ctrl-block">
        <div className="ctrl-subtitle">Configuration Summary</div>
        <div className="ctrl-content">
          <div className="sb-out-summary-grid">
            <div className="sb-out-badge">
              <span className="sb-out-badge-label">Planets</span>
              <span className="sb-out-badge-value">{planets.length}</span>
            </div>
            <div className="sb-out-badge">
              <span className="sb-out-badge-label">Stars</span>
              <span className="sb-out-badge-value">{numStars}</span>
            </div>
            <div className="sb-out-badge">
              <span className="sb-out-badge-label">UV Rows</span>
              <span className="sb-out-badge-value">{stParsedUvs.length}</span>
            </div>
            <div className="sb-out-badge">
              <span className="sb-out-badge-label">Cirrus Layers</span>
              <span className="sb-out-badge-value">{cirrusLayers.length}</span>
            </div>
            <div className={`sb-out-badge ${ready ? 'sb-out-badge--ok' : 'sb-out-badge--warn'}`}>
              <span className="sb-out-badge-label">Map</span>
              <span className="sb-out-badge-value">{ready ? 'Ready' : 'Not set'}</span>
            </div>
          </div>

          {!ready && (
            <p className="sb-field-help">
              Set <strong>Map Name</strong> and <strong>Maps Folder</strong> in the Atmosphere section to enable generation.
            </p>
          )}
        </div>
      </div>

      {/* ── Lua Preview ─────────────────────────────────────────── */}
      <div className="ctrl-block">
        <div className="ctrl-subtitle">Lua Preview</div>
        <div className="ctrl-content">
          <p className="sb-field-help">
            Read-only preview of the <code>skyBox</code> block that will be written into <code>data.lua</code>.
            The first {MAX_PREVIEW.toLocaleString()} characters are shown.
          </p>
          <pre className="sb-out-lua-preview">
            {previewTrunc || '— configure Atmosphere, Cirrus, Planets, and Stars to generate a preview —'}
          </pre>
        </div>
      </div>

      {/* ── Export Options + Generate ────────────────────────────── */}
      <OutputChecklist
        ready={ready}
        onCommit={onInjectSkybox}
        commitLabel="Generate Skybox → .scmap"
        commitAriaLabel="Inject skybox into .scmap"
        items={[
          { label: 'Export raw .scmskybox JSON alongside .scmap inject', checked: !!exportRawScmskybox, onToggle: () => setExportRawScmskybox(!exportRawScmskybox) },
          { label: 'Generate README file', checked: !!generateReadme, onToggle: () => setGenerateReadme(!generateReadme) },
        ]}
      />

      <div className="ctrl-block">
        <div className="ctrl-content">
          <div className="ctrl-action-row">
            <button
              className="action-button action-button--full"
              onClick={onExportScmskybox}
              disabled={!ready}
              title={ready ? 'Export skyBox JSON as .scmskybox file' : 'Map Name and Maps Folder required'}
            >
              Export .scmskybox only
            </button>
          </div>
          <p className="sb-field-help">
            Inject unpacks the <code>.scmap</code>, replaces only the <code>skyBox</code> block in <code>data.lua</code>,
            and repacks — all other map data is preserved. Close FA before running inject.
          </p>
        </div>
      </div>

    </div>
  );
};

export default Output;
