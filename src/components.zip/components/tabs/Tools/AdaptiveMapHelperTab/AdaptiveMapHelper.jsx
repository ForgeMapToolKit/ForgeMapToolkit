import { useState, useRef, useEffect } from "react";
import '../../../shared/shared.css';
import './AdaptiveMapHelper.css';
import AMHHelpModal from '../../HelpModals/AdaptiveMapHelper_help.jsx';

// ── Asset paths ──────────────────────────────────────────────────────────────
// Resolved once via IPC so they work in both dev (localhost) and prod (file://)
let ICON_MASS   = '';
let ICON_ENERGY = '';
let ICON_ACU    = '';  // ACU_SPAWN.png — desaturated generic
const ICON_ACU_ARMY = Array(16).fill(''); // ARMY_1.png … ARMY_16.png

window.electronAPI.invoke('get-asset-base-url').then(({ baseUrl }) => {
  ICON_MASS   = baseUrl + '/assets/icons/Library/mass.png';
  ICON_ENERGY = baseUrl + '/assets/icons/Library/energy.png';
  ICON_ACU    = baseUrl + '/assets/ACU/ACU_SPAWN.png';
  for (let i = 0; i < 16; i++) {
    ICON_ACU_ARMY[i] = baseUrl + `/assets/ACU/ARMY_${i+1}.png`;
  }
}).catch(() => {
  ICON_MASS   = '/assets/icons/Library/mass.png';
  ICON_ENERGY = '/assets/icons/Library/energy.png';
  ICON_ACU    = '/assets/ACU/ACU_SPAWN.png';
  for (let i = 0; i < 16; i++) {
    ICON_ACU_ARMY[i] = `/assets/ACU/ARMY_${i+1}.png`;
  }
});

// Returns the per-army coloured icon, fallback to generic ACU_SPAWN
const getAcuIcon = idx => ICON_ACU_ARMY[idx] || ICON_ACU;

// ── Icon loader hook ─────────────────────────────────────────────────────────
// Forces a re-render once the async IPC icon URLs have resolved
function useIconsReady() {
  const [ready, setReady] = useState(ICON_MASS !== '');
  useEffect(() => {
    if (ICON_MASS !== '') { setReady(true); return; }
    const id = setInterval(() => { if (ICON_MASS !== '') { setReady(true); clearInterval(id); } }, 50);
    return () => clearInterval(id);
  }, []);
  return ready;
}

// ── ACU colour filter ─────────────────────────────────────────────────────────
// Converts a hex colour to a CSS filter string that tints the white ACU icon.
// Strategy: brightness(0) → colour via sepia+hue-rotate+saturate.
function acuColorFilter(hex) {
  // Robust tinting: make image white first, then apply colour via drop-shadow.
  // Works on any image regardless of original colours.
  // 1. brightness(0) invert(1)  → pure white
  // 2. sepia+hue-rotate+saturate → target colour
  const r = parseInt(hex.slice(1,3),16)/255;
  const g = parseInt(hex.slice(3,5),16)/255;
  const b = parseInt(hex.slice(5,7),16)/255;
  const max=Math.max(r,g,b), min=Math.min(r,g,b), d=max-min;
  let h=0;
  if(d>0){
    if(max===r) h=((g-b)/d+6)%6;
    else if(max===g) h=(b-r)/d+2;
    else h=(r-g)/d+4;
    h*=60;
  }
  const s   = max===0 ? 0 : d/max;
  const hueRot = Math.round(h - 36);          // sepia baseline ≈ 36°
  const sat    = Math.max(1, Math.round(s * 900));
  const br     = Math.max(50, Math.round(max * 200));
  return `brightness(0) invert(1) sepia(1) saturate(${sat}%) hue-rotate(${hueRot}deg) brightness(${br}%)`;
}

// ── Lua Parser ───────────────────────────────────────────────────────────────
// Searches the entire source for named markers that have a position field.
// This avoids the old two-step approach (markerBlock regex → entryRe) which
// silently dropped the last marker in the file when its closing } coincided
// with the lookahead terminator of the outer regex.
function parseSaveLua(src) {
  const armies = {}, mass = {}, hydro = {};
  // Match every named marker that contains a position — works regardless of
  // where the marker sits in the file (first, last, or middle).
  const entryRe = /\['([^']+)'\]\s*=\s*\{[\s\S]*?position'\]\s*=\s*VECTOR3\(\s*([\d.]+),\s*[\d.]+,\s*([\d.]+)\s*\)/g;
  let m;
  while ((m = entryRe.exec(src)) !== null) {
    const name = m[1];
    const x = parseFloat(m[2]), y = parseFloat(m[3]);
    if      (name.match(/^ARMY_\d+$/))    armies[name] = { x, y };
    else if (name.startsWith('Mass '))    mass[name.replace('Mass ','').trim()]            = { x, y };
    else if (name.startsWith('Hydrocarbon ')) hydro[name.replace('Hydrocarbon ','').trim()] = { x, y };
  }
  return { armies, mass, hydro };
}

// ── Constants ────────────────────────────────────────────────────────────────
// Exact colours from Photopea — matches ARMY_1.png … ARMY_16.png
const ARMY_COLORS = [
  '#ef0808', //  1  Red
  '#941421', //  2  Dark Red
  '#ff8639', //  3  Orange
  '#b56518', //  4  Dark Orange
  '#a59600', //  5  Olive
  '#fffb00', //  6  Yellow
  '#9cdb00', //  7  Yellow-Green
  '#42be42', //  8  Green
  '#298a52', //  9  Teal-Green
  '#294d4a', // 10  Dark Teal
  '#426def', // 11  Cornflower Blue
  '#2928e7', // 12  Blue
  '#5a00a5', // 13  Purple
  '#9461ff', // 14  Lavender
  '#63ffce', // 15  Cyan-Mint
  '#ff8aff', // 16  Pink
];

const ALL_TYPE_META = {
  spawnMex:   { label:'Spawn Mex',   color:'#64b5f6' },
  spawnHydro: { label:'Spawn Hydro', color:'#81c784' },
};

// ── Options Generator ─────────────────────────────────────────────────────────
function generateOptionsLua() {
  return `--[[  Generated by ForgeMapToolkit - Adaptive Map Helper  ]]--

options ={

{
    default = 1,
    label = "<LOC adaptive_dynamic_spawn_label> Dynamic Spawn Of Resources",
    help = "<LOC adaptive_dynamic_spawn_help> Determine which mexes & hydros should be spawned.",
    key = 'dynamic_spawn',
    pref = 'dynamic_spawn',
    values = {
        { text = "<LOC adaptive_dynamic_spawn_key_1_label> mirror slots", help = "<LOC adaptive_dynamic_spawn_key_1_help> Spawn resources for player & mirror slot (balanced resources).", key = 1, },
        { text = "<LOC adaptive_dynamic_spawn_key_2_label> used slots", help = "<LOC adaptive_dynamic_spawn_key_2_help> Only spawn resources for player on used slots (unbalanced resources).", key = 2, },
        { text = "<LOC adaptive_dynamic_spawn_key_3_label> no mirror = no resources", help = "<LOC adaptive_dynamic_spawn_key_3_help> Only spawn resources if mirror slot is also occupied by a player.", key = 3, },
    },
},

{
    default = 1,
    label = "<LOC adaptive_crazyrush_label> Crazyrush",
    help = "<LOC adaptive_crazyrush_help> Activate different types of crazyrush for the spawned mexes.",
    key = 'crazyrush_mexes',
    pref = 'crazyrush_mexes',
    values = {
        { text = "<LOC adaptive_disabled> disabled", help = "<LOC adaptive_crazyrush_key_1_help> No crazyrush.", key = 1, },
        { text = "<LOC adaptive_crazyrush_key_4_label> crazyrush", help = "<LOC adaptive_crazyrush_key_4_help> Activate crazyrush for all spawned mexes.", key = 4, },
    },
},

};
`;
}

// ── Script Generator ──────────────────────────────────────────────────────────
function generateScriptLua(mapName) {
  const name      = (mapName||'').trim();
  const finalName = /\.v\d{4}$/.test(name) ? name : name+'.v0001';
  // baseName must be the exact folder name without version suffix.
  // e.g. "adaptive_Tartaron.v0006" → baseName = "adaptive_Tartaron"
  // so the import path becomes /maps/adaptive_Tartaron.v0006/adaptive_Tartaron_tables.lua
  const baseName  = finalName.replace(/\.v\d{4}$/, '');
  const importPath = `/maps/${finalName}/${baseName}_tables.lua`;
  return `------------------------------------------------------------------------
----- Generated by ForgeMapToolkit - Adaptive Map Helper            -----
------------------------------------------------------------------------
local ScenarioUtils = import('/lua/sim/ScenarioUtilities.lua')
local ScenarioFramework = import('/lua/ScenarioFramework.lua')
local Tables = import('${importPath}')

------------------------------------------------------------------------
----- Options ----------------------------------------------------------
------------------------------------------------------------------------
local maxPlayerOnMap  = Tables.maxPlayerOnMap or 16
local dynamic_spawn   = ScenarioInfo.Options.dynamic_spawn   or 1
local crazyrush_mexes = ScenarioInfo.Options.crazyrush_mexes or 1

------------------------------------------------------------------------
----- Crazyrush state --------------------------------------------------
------------------------------------------------------------------------
local spawnedMassSpots = {}
local spawnedMexNumber = 0
local currentResSpot   = 0
local generatedMass    = {}
local checkedExtractor = {}
local MexList          = {}
math.randomseed(1)

------------------------------------------------------------------------
----- Initialization ---------------------------------------------------
------------------------------------------------------------------------
function OnPopulate()
    LOG("ADAPTIVE: OnPopulate")
    ScenarioUtils.InitializeArmies()
end

function OnStart()
    LOG("ADAPTIVE: OnStart")
    if crazyrush_mexes > 1 then
        ForkThread(Crazyrush_checkMassPoint)
    end
end

------------------------------------------------------------------------
----- Dynamic resource spawning ----------------------------------------
------------------------------------------------------------------------
-- Overrides the engine default. Decides which Mass/Hydro markers spawn
-- based on which armies are present and the dynamic_spawn option.
function ScenarioUtils.CreateResources()
    LOG("ADAPTIVE: CreateResources()")

    local markers       = ScenarioUtils.GetMarkers()
    local spwnMexArmy   = Tables.spwnMexArmy   or {}
    local spwnHydroArmy = Tables.spwnHydroArmy or {}

    -- Build list of present armies: real players + lobby-selected spawn positions.
    -- SpawnMex contains positions selected via the FAF close-spawn / position picker.
    -- A slot marked true counts as occupied even without a real player sitting there.
    local ArmyList = ListArmies()
    for j, spawnmex in ScenarioInfo.Options.SpawnMex or {} do
        if spawnmex then
            ArmyList[table.getn(ArmyList) + 1] = 'ARMY_' .. j
        end
    end

    local Notpresentarmies = {}
    local notPresentCount  = 1

    if dynamic_spawn == 1 then
        -- Mirror-slot: skip pair if neither army of the pair is present
        for m = 1, maxPlayerOnMap / 2 do
            local a1 = 2*m - 1
            local a2 = 2*m
            local present = 0
            for _, army in ArmyList do
                if army == ("ARMY_" .. a1) or army == ("ARMY_" .. a2) then
                    present = present + 1
                end
            end
            if present < 1 then
                Notpresentarmies[notPresentCount] = a1; notPresentCount = notPresentCount + 1
                Notpresentarmies[notPresentCount] = a2; notPresentCount = notPresentCount + 1
            end
        end

    elseif dynamic_spawn == 2 then
        -- Used-slots: skip each individually absent army
        for m = 1, maxPlayerOnMap do
            local found = false
            for _, army in ArmyList do
                if army == ("ARMY_" .. m) then found = true; break end
            end
            if not found then
                Notpresentarmies[notPresentCount] = m
                notPresentCount = notPresentCount + 1
            end
        end

    elseif dynamic_spawn == 3 then
        -- Strict mirror: skip both slots unless BOTH are present
        for m = 1, maxPlayerOnMap / 2 do
            local a1 = 2*m - 1
            local a2 = 2*m
            local present = 0
            for _, army in ArmyList do
                if army == ("ARMY_" .. a1) or army == ("ARMY_" .. a2) then
                    present = present + 1
                end
            end
            if present < 2 then
                Notpresentarmies[notPresentCount] = a1; notPresentCount = notPresentCount + 1
                Notpresentarmies[notPresentCount] = a2; notPresentCount = notPresentCount + 1
            end
        end
    end

    LOG("ADAPTIVE: absent army slots = ", notPresentCount - 1)

    for name, tblData in pairs(markers) do
        if tblData.resource then
            local doit = true

            -- Remove markers belonging to absent armies
            for _, armynumber in Notpresentarmies do
                doit = FalseIfInList(name, spwnMexArmy[armynumber]   or {}, MassString,  doit)
                doit = FalseIfInList(name, spwnHydroArmy[armynumber] or {}, HydroString, doit)
            end

            if doit then
                if tblData.type == 'Mass' then
                    spawnedMexNumber = spawnedMexNumber + 1
                    spawnedMassSpots[spawnedMexNumber] = name
                end
                SpawnResource(tblData.position, tblData.type)
            end
        end
    end

    LOG("ADAPTIVE: spawned ", spawnedMexNumber, " mass spots")
end

------------------------------------------------------------------------
----- Helpers ----------------------------------------------------------
------------------------------------------------------------------------
function MassString(n)
    if n > 9 then return "Mass " .. n else return "Mass 0" .. n end
end

function HydroString(n)
    if n > 9 then return "Hydrocarbon " .. n else return "Hydrocarbon 0" .. n end
end

function FalseIfInList(name, list, stringFn, _doit)
    for k = 1, table.getn(list) do
        if name == stringFn(list[k]) then return false end
    end
    return _doit
end

function SpawnResource(position, restype)
    local albedo, bp, lod, size
    if restype == 'Mass' then
        albedo = "/env/common/splats/mass_marker.dds"
        bp     = "/env/common/props/massDeposit01_prop.bp"
        lod    = 100
        size   = 2
    else
        albedo = "/env/common/splats/hydrocarbon_marker.dds"
        bp     = "/env/common/props/hydrocarbonDeposit01_prop.bp"
        lod    = 200
        size   = 6
    end
    CreateSplat(position, 0, albedo, size, size, lod, 0, -1, 0)
    CreateResourceDeposit(restype, position[1], position[2], position[3], size/2)
    CreatePropHPR(bp, position[1], position[2], position[3], Random(0, 360), 0, 0)
end

------------------------------------------------------------------------
----- Crazyrush --------------------------------------------------------
------------------------------------------------------------------------
function Crazyrush_checkMassPoint()
    while true do
        local units = GetUnitsInRect({x0=0, x1=ScenarioInfo.size[1], y0=0, y1=ScenarioInfo.size[2]})
        if units then
            for _, unit in units do
                if EntityCategoryContains(categories.MASSEXTRACTION, unit) then
                    local px = unit:GetPosition()[1]
                    local pz = unit:GetPosition()[3]
                    if not Crazyrush_alreadyChecked(px, pz) then
                        Crazyrush_TrySpawn(px - 2, pz)
                        Crazyrush_TrySpawn(px + 2, pz)
                        Crazyrush_TrySpawn(px,     pz - 2)
                        Crazyrush_TrySpawn(px,     pz + 2)
                    end
                    WaitSeconds(0.01)
                end
            end
        end
        WaitSeconds(1)
    end
end

function Crazyrush_alreadyChecked(x, y)
    if checkedExtractor[x] == nil then
        checkedExtractor[x] = {}; checkedExtractor[x][y] = true; return false
    elseif checkedExtractor[x][y] == nil then
        checkedExtractor[x][y] = true; return false
    end
    return true
end

function Crazyrush_TrySpawn(x, y)
    if generatedMass[x] and generatedMass[x][y] then return end
    if generatedMass[x] == nil then generatedMass[x] = {} end
    generatedMass[x][y] = true
    SpawnResource(VECTOR3(x, GetTerrainHeight(x,y), y), 'Mass')
    MexList[table.getn(MexList)+1] = {x, y}
end
`;
}

// ── Tables Generator ──────────────────────────────────────────────────────────
function generateTablesLua(armyList, assignments, maxPlayers) {
  const armies = armyList.filter(a => a !== 'ARMY_17');
  const spwnMex = {}, spwnHydro = {};
  armies.forEach(a => { spwnMex[a]=[]; spwnHydro[a]=[]; });

  Object.entries(assignments).forEach(([key, { type, army }]) => {
    if      (type==='spawnMex'   && army && army!=='ARMY_17') spwnMex[army].push(key);
    else if (type==='spawnHydro' && army && army!=='ARMY_17') spwnHydro[army].push(key);
  });

  const fmtNum  = n => String(parseInt(n, 10));
  const fmtArmy = tbl => armies.map(a=>`\t\t\t\t{${(tbl[a]||[]).map(fmtNum).join(',')}}`).join(',\n');

  return `--[[  Generated by ForgeMapToolkit - Adaptive Map Helper  ]]--\n\nmaxPlayerOnMap = ${maxPlayers}\n\nspwnMexArmy = {\n${fmtArmy(spwnMex)}\n}\n\nspwnHydroArmy = {\n${fmtArmy(spwnHydro)}\n}\n`;
}

// ── Main Component ───────────────────────────────────────────────────────────
export default function AdaptiveMapHelper({ settings, shared={}, onSharedChange=()=>{} }) {

  const [mapName, setMapNameState] = useState(shared.amh_mapName ?? '');
  const setMapName = v => { setMapNameState(v); onSharedChange('amh_mapName', v); };

  const [mapInfo,       setMapInfo]       = useState(null);
  const [mapSize,       setMapSize]       = useState(1024);
  const [parsed,        setParsed]        = useState(null);
  const [assignments,   setAssignments]   = useState({});
  const [activePanel,   setActivePanel]   = useState('map');
  const [generatedCode, setGeneratedCode] = useState('');
  const [previewDataUrl,setPreviewDataUrl]= useState(null);
  const [previewLoading,setPreviewLoading]= useState(false);
  const previewInputRef = useRef();
  const [mirrorMode,    setMirrorMode]    = useState(false);
  const [quickArmy,     setQuickArmy]     = useState(null); // army key or null
  const [adaptiveStatus, setAdaptiveStatus] = useState(null); // null | 'running' | 'done' | 'error' | 'already'
  const [adaptiveMsg,    setAdaptiveMsg]    = useState('');
  const [showHelp,       setShowHelp]       = useState(false);
  const [activeHelpTab,  setActiveHelpTab]  = useState('guide');
  const [helpSelected,   setHelpSelected]   = useState(null);
  const [helpAdvSubTab,  setHelpAdvSubTab]  = useState('overview');
 
  // Check whether the current mapName already has the adaptive_ prefix
  const isAlreadyAdaptive = (() => {
    const n = (mapName || '').trim().toLowerCase();
    // Extract the base name without .vNNNN
    const base = n.replace(/\.v\d{4}$/, '');
    return base.startsWith('adaptive_');
  })();
 
 
  // Reset preview when map changes
  useEffect(() => {
    setPreviewDataUrl(null);
  }, [mapName, settings?.mapsFolder]);

  const loadPreviewFromScmap = async (mapFolderPath) => {
    try {
      setPreviewLoading(true);
      const dirRes = await window.electronAPI.invoke('list-dir', { dirPath: mapFolderPath });
      if (!dirRes?.success) return;
      const scmapEntry = dirRes.entries.find(e => !e.isDirectory && e.name.toLowerCase().endsWith('.scmap'));
      if (!scmapEntry) return;
      const scmapPath = mapFolderPath + '\\' + scmapEntry.name;
      const unpackRes = await window.electronAPI.invoke('scmap-unpack', { scmapPath });
      if (!unpackRes?.success) return;
      const unpackDir = await window.electronAPI.invoke('list-dir', { dirPath: unpackRes.outputFolder });
      if (!unpackDir?.success) return;
      const previewEntry = unpackDir.entries.find(e => /^previewimage/i.test(e.name));
      if (!previewEntry) return;
      const ddsPath = unpackRes.outputFolder + '\\' + previewEntry.name;
      const ddsRes = await window.electronAPI.invoke('dds-to-dataurl', { filePath: ddsPath });
      if (ddsRes?.success && ddsRes.dataUrl) setPreviewDataUrl(ddsRes.dataUrl);
    } catch (e) {
      console.warn('[AMH] preview load failed:', e);
    } finally {
      setPreviewLoading(false);
    }
  };

  const handleCustomPreviewUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setPreviewDataUrl(ev.target.result);
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  useEffect(() => {
    const name   = (mapName||'').trim();
    const folder = (settings?.mapsFolder||'').trim();
    if (!name||!folder) { setMapInfo(null); setParsed(null); return; }
    const finalName     = /\.v\d{4}$/.test(name) ? name : name+'.v0001';
    const mapFolderPath = folder+'\\'+finalName;

    window.electronAPI.invoke('read-map-info',{mapFolderPath}).then(res=>{
      if (res?.success) {
        setMapInfo({ok:true, mapSize:res.mapSize, km:res.km, playableSize:res.playableSize});
        setMapSize(res.playableSize||1024);
      } else setMapInfo({ok:false});
    }).catch(()=>setMapInfo({ok:false}));

    // Load preview image from scmap
    loadPreviewFromScmap(mapFolderPath);

    window.electronAPI.invoke('list-dir',{dirPath:mapFolderPath}).then(async res=>{
      if (!res?.success) { setParsed(null); return; }
      const saveEntry = res.entries.find(e=>!e.isDirectory&&e.name.toLowerCase().endsWith('_save.lua'));
      if (!saveEntry) { setParsed(null); return; }
      const fileRes = await window.electronAPI.invoke('read-file',{path:mapFolderPath+'\\'+saveEntry.name});
      if (fileRes?.success&&fileRes.content) { setParsed(parseSaveLua(fileRes.content)); setAssignments({}); }
      else setParsed(null);
    }).catch(()=>setParsed(null));
  }, [mapName, settings?.mapsFolder]);

  const armyList   = parsed ? Object.keys(parsed.armies).sort((a,b)=>parseInt(a.replace('ARMY_',''))-parseInt(b.replace('ARMY_',''))) : [];
  const maxPlayers = armyList.filter(a=>a!=='ARMY_17').length;

  const removeAssignment = key => setAssignments(prev=>{ const n={...prev}; delete n[key]; return n; });

  const handleGenerate = async () => {
    if (!parsed) return;

    // ── Auto-rename to adaptive_ BEFORE writing files ─────────────────────────
    // If the map folder doesn't have the adaptive_ prefix yet, rename it first
    // so the generated files land in the correctly-named folder.
    if (!isAlreadyAdaptive) {
      const name   = (mapName||'').trim();
      const folder = (settings?.mapsFolder||'').trim();
      if (name && folder) {
        const finalName     = /\.v\d{4}$/.test(name) ? name : name + '.v0001';
        const mapFolderPath = folder + '\\' + finalName;

        setAdaptiveStatus('running');
        setAdaptiveMsg('');

        try {
          const res = await window.electronAPI.invoke('make-map-adaptive', { mapFolder: mapFolderPath });

          if (res?.alreadyAdaptive) {
            setAdaptiveStatus('already');
            setAdaptiveMsg('Map already has the adaptive_ prefix.');
          } else if (res?.success) {
            setMapName(res.newFolderName);
            setAdaptiveStatus('done');
            setAdaptiveMsg(
              `✓ Renamed to ${res.newFolderName}` +
              ` · ${res.renamedFiles?.length ?? 0} files · ${res.patchedFiles?.length ?? 0} Lua files patched`
            );
            // Continue generate with the new (adaptive_) map name
            const adaptiveFinalName = res.newFolderName;
            const adaptiveBaseName  = adaptiveFinalName.replace(/\.v\d{4}$/, '');
            const adaptiveFolder    = folder + '\\' + adaptiveFinalName;
            const tables  = generateTablesLua(armyList, assignments, maxPlayers);
            const options = generateOptionsLua();
            // Pass the full versioned name so the import path uses the correct version suffix
            const script  = generateScriptLua(adaptiveFinalName);
            setGeneratedCode(tables);
            setActivePanel('code');
            try {
              await Promise.all([
                window.electronAPI.invoke('write-file', { filePath: adaptiveFolder + '\\' + adaptiveBaseName + '_tables.lua',  content: tables  }),
                window.electronAPI.invoke('write-file', { filePath: adaptiveFolder + '\\' + adaptiveBaseName + '_options.lua', content: options }),
                window.electronAPI.invoke('write-file', { filePath: adaptiveFolder + '\\' + adaptiveBaseName + '_script.lua',  content: script  }),
              ]);
            } catch(e) { console.warn('[AMH] write-file failed after rename:', e); }
            return;
          } else {
            setAdaptiveStatus('error');
            setAdaptiveMsg(res?.error || 'Rename failed');
            // Still attempt to write files into the original folder
          }
        } catch (e) {
          setAdaptiveStatus('error');
          setAdaptiveMsg(String(e?.message || e));
        }
      }
    }

    // ── Write files (map is already adaptive, or rename was skipped/failed) ───
    const name   = (mapName||'').trim();
    const folder = (settings?.mapsFolder||'').trim();
    if (!name||!folder) return;
    const finalName     = /\.v\d{4}$/.test(name) ? name : name+'.v0001';
    const mapFolderPath = folder+'\\'+finalName;
    const baseName = finalName.replace(/\.v\d{4}$/, '');

    const tables  = generateTablesLua(armyList, assignments, maxPlayers);
    const options = generateOptionsLua();
    // Pass the full versioned name so the import path uses the correct version suffix
    const script  = generateScriptLua(finalName);

    setGeneratedCode(tables);
    setActivePanel('code');

    try {
      await Promise.all([
        window.electronAPI.invoke('write-file', { filePath: mapFolderPath+'\\'+baseName+'_tables.lua',  content: tables  }),
        window.electronAPI.invoke('write-file', { filePath: mapFolderPath+'\\'+baseName+'_options.lua', content: options }),
        window.electronAPI.invoke('write-file', { filePath: mapFolderPath+'\\'+baseName+'_script.lua',  content: script  }),
      ]);
    } catch(e) {
      console.warn('[AMH] write-file failed:', e);
    }
  };

  const assigned     = Object.keys(assignments).length;
  const totalMarkers = parsed ? Object.keys(parsed.mass).length + Object.keys(parsed.hydro).length : 0;

  return (
    <div className="amh-tab tab-scrollbar">

      {/* ── Help button — shared.css .help-btn ── */}
      <button className="help-btn" onClick={() => setShowHelp(h => !h)} title="Help Guide">?</button>

      {/* ── Help modal ── */}
      {showHelp && (
        <AMHHelpModal
          onClose={() => setShowHelp(false)}
          activeTab={activeHelpTab}
          setActiveTab={t => { setActiveHelpTab(t); setHelpSelected(null); }}
          helpSelected={helpSelected}
          setHelpSelected={setHelpSelected}
          helpAdvSubTab={helpAdvSubTab}
          setHelpAdvSubTab={setHelpAdvSubTab}
        />
      )}

      {/* ── Header ── */}
      <div className="amh-header-card">
        <div className="amh-header-left">
          <span className="amh-header-icon">⬡</span>
          <div>
            <div className="amh-header-title">Adaptive Map Helper</div>
            <div className="amh-header-sub">ForgeMapToolkit</div>
          </div>
        </div>

        <div className="amh-mapname-wrap">
          <label className="amh-form-label">Map Name</label>
          <input
            className="amh-form-input"
            type="text"
            value={mapName}
            onChange={e=>setMapName(e.target.value)}
            placeholder="e.g. Hades_Dust.v0002"
          />
          {mapName&&!settings?.mapsFolder&&<div className="amh-map-info error">✕ Maps folder not set in Settings</div>}
          {mapInfo&&(
            <div className={`amh-map-info${mapInfo.ok?'':' error'}`}>
              {mapInfo.ok ? `✓  ${mapInfo.mapSize}×${mapInfo.mapSize} px · ${mapInfo.km} km · playable ${mapInfo.playableSize} px`
                          : '✕  Map not found — check name or Maps Folder in Settings'}
            </div>
          )}
        </div>


          {/* ── Status feedback after Make-Adaptive ── */}
          {adaptiveStatus === 'done' && (
            <div className="amh-adaptive-result ok">{adaptiveMsg}</div>
          )}
          {adaptiveStatus === 'already' && (
            <div className="amh-adaptive-result ok">✓ {adaptiveMsg}</div>
          )}
          {adaptiveStatus === 'error' && (
            <div className="amh-adaptive-result error">✕ {adaptiveMsg}</div>
          )}
          
        {parsed&&(
          <div className="amh-header-stats">
            <div className="amh-stat-pill">
              <img src={ICON_MASS}   alt="mass"  className="amh-stat-icon" />
              <span>{Object.keys(parsed.mass).length}</span>
            </div>
            <div className="amh-stat-pill">
              <img src={ICON_ENERGY} alt="hydro" className="amh-stat-icon" />
              <span>{Object.keys(parsed.hydro).length}</span>
            </div>
            <div className="amh-stat-pill">
              <img src={ICON_ACU} alt="armies" className="amh-stat-icon" />
              <span>{maxPlayers}</span>
            </div>
            <div className="amh-stat-pill amh-stat-pill--assigned">
              <span>{assigned} / {totalMarkers} assigned</span>
            </div>
          </div>
        )}
      </div>

      {/* ── Editor ── */}
      {!parsed ? (
        <div className="amh-empty-state">
          <div className="amh-empty-icon">⬡</div>
          <div className="amh-empty-title">{mapName?'Loading save.lua…':'Enter a map name above to begin'}</div>
          <div className="amh-empty-sub">{mapName?`Searching in ${settings?.mapsFolder||'(no maps folder set)'}` :'The _save.lua will be read automatically'}</div>
        </div>
      ) : (
        <div className="amh-editor">
          <div className="amh-canvas-panel">
            <div className="amh-panel-tabs">
              {[{id:'map',label:'⊞ Map View'},{id:'code',label:'{ } tables.lua'}].map(p=>(
                <button key={p.id} className={`amh-panel-tab${activePanel===p.id?' active':''}`} onClick={()=>setActivePanel(p.id)}>{p.label}</button>
              ))}
              <div style={{flex:1}}/>
              <input ref={previewInputRef} type="file" accept="image/*,.dds" style={{display:'none'}} onChange={handleCustomPreviewUpload}/>
              {previewLoading
                ? <span className="amh-preview-loading">loading preview…</span>
                : <button className="amh-preview-upload-btn" title="Load custom preview image (PNG/JPG/DDS)" onClick={()=>previewInputRef.current?.click()}>🖼 Preview</button>
              }
              <button
                className={`amh-toolbar-toggle${mirrorMode?' active':''}`}
                title="Mirror Mode: assign clicked marker + its map-centre mirror"
                onClick={()=>setMirrorMode(m=>!m)}>⇌ Mirror</button>
              <div className="amh-quick-army-wrap">
                <span className="amh-quick-label">Quick:</span>
                {armyList.filter(a=>a!=='ARMY_17').map(army=>{
                  const idx=parseInt(army.replace('ARMY_',''))-1;
                  const col=ARMY_COLORS[idx%ARMY_COLORS.length];
                  return (
                    <button key={army}
                      className={`amh-quick-army-btn${quickArmy===army?' active':''}`}
                      style={{'--qcol':col}}
                      title={`Quick-assign → ${army}`}
                      onClick={()=>setQuickArmy(q=>q===army?null:army)}>
                      <img src={getAcuIcon(idx)} alt="" style={{width:13,height:13,imageRendering:'pixelated',flexShrink:0}}/>
                      <span className="amh-quick-army-label">ARMY_{idx+1}</span>
                    </button>
                  );
                })}
              </div>
              <button className="amh-generate-btn-inline" onClick={handleGenerate}>⬡ Generate &amp; Save All Files</button>
            </div>

            {activePanel==='map' ? (
              <MapCanvas
                parsed={parsed}
                mapSize={mapSize}
                assignments={assignments}
                armyList={armyList}
                armyColors={ARMY_COLORS}
                onAssign={(key,asgn)=>setAssignments(prev=>({...prev,[key]:asgn}))}
                onRemove={removeAssignment}
                previewDataUrl={previewDataUrl}
                mirrorMode={mirrorMode}
                quickArmy={quickArmy}
              />
            ) : (
              <div className="amh-code-wrap">
                {generatedCode ? (
                  <>
                    <div className="amh-code-header">
                      <span className="amh-code-label">tables.lua · options.lua · script.lua — generated &amp; saved</span>
                      <button className="amh-copy-btn" onClick={()=>navigator.clipboard.writeText(generatedCode)}>Copy tables.lua</button>
                    </div>
                    <div className="amh-code-saved-note">
                      ✓ All 3 files were written directly into your map folder.
                    </div>
                    <pre className="amh-code-pre">{generatedCode}</pre>
                  </>
                ) : (
                  <div className="amh-code-empty">
                    <div className="amh-code-empty-icon">{ }</div>
                    <span>Assign resources on the map view, then click Generate &amp; Save All Files.</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Map Canvas ───────────────────────────────────────────────────────────────
function MapCanvas({ parsed, mapSize, assignments, armyList, armyColors, onAssign, onRemove, previewDataUrl, mirrorMode, quickArmy }) {
  useIconsReady(); // re-render once icon URLs are resolved
  const wrapRef        = useRef();
  const [camera, setCamera] = useState({ x:0, y:0, zoom:1 });
  const cameraRef      = useRef({ x:0, y:0, zoom:1 });
  const dragRef        = useRef(null);
  const mousePosRef    = useRef(null);
  const insideRef      = useRef(false);
  const [hover, setHover]   = useState(null);
  const [popup, setPopup]   = useState(null);
  const [size,  setSize]    = useState({ w:800, h:600 });

  // Keep cameraRef in sync so wheel handler always has current values
  useEffect(() => { cameraRef.current = camera; }, [camera]);

  useEffect(() => {
    const measure = () => {
      if (wrapRef.current) setSize({ w:wrapRef.current.clientWidth, h:wrapRef.current.clientHeight });
    };
    measure();
    const ro = new ResizeObserver(measure);
    if (wrapRef.current) ro.observe(wrapRef.current);
    return () => ro.disconnect();
  }, []);

  // Register wheel as non-passive so preventDefault() works
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const onWheel = e => {
      e.preventDefault();
      const rect  = el.getBoundingClientRect();
      const mx    = e.clientX - rect.left;   // mouse x in canvas px
      const my    = e.clientY - rect.top;    // mouse y in canvas px
      const c     = cameraRef.current;
      const factor = e.deltaY < 0 ? 1.12 : 0.89;
      const newZoom = Math.max(0.3, Math.min(10, c.zoom * factor));

      // World point under mouse before zoom
      const wx = (mx - c.x - rect.width  / 2) / c.zoom;
      const wy = (my - c.y - rect.height / 2) / c.zoom;

      // Shift camera so that same world point stays under mouse after zoom
      const newX = mx - rect.width  / 2 - wx * newZoom;
      const newY = my - rect.height / 2 - wy * newZoom;

      setCamera({ x: newX, y: newY, zoom: newZoom });
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);

  const w2s = (wx,wy) => ({
    cx: Math.round(size.w/2 + (wx/mapSize-0.5)*mapSize*camera.zoom + camera.x),
    cy: Math.round(size.h/2 + (wy/mapSize-0.5)*mapSize*camera.zoom + camera.y),
  });
  const s2w = (sx,sy) => ({
    wx: ((sx-camera.x-size.w/2)/camera.zoom/mapSize+0.5)*mapSize,
    wy: ((sy-camera.y-size.h/2)/camera.zoom/mapSize+0.5)*mapSize,
  });

  const hitTest = (wx,wy,tx,ty,r) => Math.abs(wx-tx)<r && Math.abs(wy-ty)<r;

  const handleMouseDown = e=>{ if(e.button===1||e.button===2) dragRef.current={sx:e.clientX,sy:e.clientY,ox:camera.x,oy:camera.y}; };
  const handleMouseMove = e=>{ const d=dragRef.current; if(d) setCamera(c=>({...c,x:d.ox+e.clientX-d.sx,y:d.oy+e.clientY-d.sy})); };
  const handleMouseUp   = ()=>{ dragRef.current=null; };

  const handleMouseMoveHover = e => {
    handleMouseMove(e);
    // Track mouse position relative to canvas for edge-scroll
    const rect = wrapRef.current?.getBoundingClientRect();
    if (rect) mousePosRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    if (popup) return;
    if (!rect) return;
    const {wx,wy} = s2w(e.clientX-rect.left, e.clientY-rect.top);
    const thr = 10/camera.zoom;
    for (const [k,{x,y}] of Object.entries(parsed.mass))  { if(hitTest(wx,wy,x,y,thr)){setHover({key:k,kind:'mass', x,y});return;} }
    for (const [k,{x,y}] of Object.entries(parsed.hydro)) { if(hitTest(wx,wy,x,y,thr)){setHover({key:k,kind:'hydro',x,y});return;} }
    setHover(null);
  };

  // Find mirror marker: tests X-axis, Y-axis, and XY (point) mirror candidates,
  // picks whichever is closest. Threshold 8% of map size to handle imprecise maps.
  const findMirror = (hitKey, hitKind) => {
    const src = hitKind==='mass' ? parsed.mass[hitKey] : parsed.hydro[hitKey];
    if (!src) return null;
    const pool = hitKind==='mass' ? parsed.mass : parsed.hydro;
    const half = mapSize / 2;

    // Three possible mirror positions depending on map symmetry axis
    const candidates = [
      { tx: src.x,           ty: mapSize - src.y }, // X-axis  (flip Y)
      { tx: mapSize - src.x, ty: src.y           }, // Y-axis  (flip X)
      { tx: mapSize - src.x, ty: mapSize - src.y }, // XY / point (flip both)
    ];

    let best = null, bestD = Infinity;
    for (const [k, {x,y}] of Object.entries(pool)) {
      if (k === hitKey) continue;
      for (const { tx, ty } of candidates) {
        const d = Math.hypot(x - tx, y - ty);
        if (d < bestD) { bestD = d; best = k; }
      }
    }
    // Accept if within 8% of map size (looser than before to handle imprecise placement)
    return bestD < mapSize * 0.08 ? best : null;
  };

  const handleClick = e => {
    if (e.button!==0) return;
    if (popup) { setPopup(null); return; }
    const rect = wrapRef.current.getBoundingClientRect();
    const {wx,wy} = s2w(e.clientX-rect.left, e.clientY-rect.top);
    const thr = 9/camera.zoom;

    const allMarkers = [
      ...Object.entries(parsed.mass).map(([k,v])=>({k,kind:'mass',...v})),
      ...Object.entries(parsed.hydro).map(([k,v])=>({k,kind:'hydro',...v})),
    ];
    const hit = allMarkers.find(({x,y})=>hitTest(wx,wy,x,y,thr));
    if (!hit) return;

    if (quickArmy) {
      // Quick-assign mode: assign immediately, no popup
      const spawnType = hit.kind==='mass' ? 'spawnMex' : 'spawnHydro';
      const asgn = { type:spawnType, army:quickArmy };
      onAssign(hit.k, asgn);
      if (mirrorMode) {
        const mirrorKey = findMirror(hit.k, hit.kind);
        if (mirrorKey) onAssign(mirrorKey, asgn);
      }
    } else {
      // Normal mode: open popup (mirror applies after popup confirms)
      setPopup({key:hit.k, kind:hit.kind, sx:e.clientX-rect.left, sy:e.clientY-rect.top, mirrorMode});
    }
  };

  const handleRightClick = e => {
    e.preventDefault(); setPopup(null);
    const rect = wrapRef.current.getBoundingClientRect();
    const {wx,wy} = s2w(e.clientX-rect.left, e.clientY-rect.top);
    const thr = 11/camera.zoom;
    for (const [k,{x,y}] of Object.entries(parsed.mass))  { if(hitTest(wx,wy,x,y,thr)){onRemove(k);return;} }
    for (const [k,{x,y}] of Object.entries(parsed.hydro)) { if(hitTest(wx,wy,x,y,thr)){onRemove(k);return;} }
  };

  const getColor = key => {
    const a = assignments[key]; if (!a) return null;
    return a.army ? armyColors[(parseInt(a.army.replace('ARMY_',''))-1)%armyColors.length] : '#888';
  };

  // Fixed icon size — always 16px screen pixels, no sub-pixel scaling
  const iSz  = 16;
  const armR  = 12;
  const mapCorners = [w2s(0,0),w2s(mapSize,0),w2s(mapSize,mapSize),w2s(0,mapSize)];

  return (
    <div ref={wrapRef} className="amh-canvas-inner"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMoveHover}
      onMouseUp={handleMouseUp}
      onMouseEnter={()=>{ insideRef.current=true; }}
      onMouseLeave={()=>{ insideRef.current=false; mousePosRef.current=null; dragRef.current=null; }}
      onClick={handleClick}
      onContextMenu={handleRightClick}
    >
      <svg width={size.w} height={size.h} style={{display:'block',position:'absolute',inset:0}}>
        {/* Map bg */}
        <polygon points={mapCorners.map(c=>`${c.cx},${c.cy}`).join(' ')} fill="#0c1018" stroke="rgba(255,140,0,0.2)" strokeWidth={1.5}/>
        {/* Preview image as map background */}
        {previewDataUrl && (() => {
          const tl=w2s(0,0), tr=w2s(mapSize,0), bl=w2s(0,mapSize), br=w2s(mapSize,mapSize);
          const x=Math.min(tl.cx,bl.cx), y=Math.min(tl.cy,tr.cy);
          const w=Math.max(tr.cx,br.cx)-x, h=Math.max(bl.cy,br.cy)-y;
          return <image href={previewDataUrl} x={x} y={y} width={w} height={h}
            preserveAspectRatio="none" style={{imageRendering:'pixelated'}} opacity={0.55}/>;
        })()}
        {/* Grid */}
        {[0.25,0.5,0.75].map(f=>{
          const a=w2s(f*mapSize,0),b=w2s(f*mapSize,mapSize),c2=w2s(0,f*mapSize),d=w2s(mapSize,f*mapSize);
          return <g key={f}>
            <line x1={a.cx} y1={a.cy} x2={b.cx} y2={b.cy} stroke="rgba(255,255,255,0.08)" strokeWidth={0.5} strokeDasharray="4,4"/>
            <line x1={c2.cx} y1={c2.cy} x2={d.cx} y2={d.cy} stroke="rgba(255,255,255,0.08)" strokeWidth={0.5} strokeDasharray="4,4"/>
          </g>;
        })}

        {/* Mass markers */}
        {Object.entries(parsed.mass).map(([key,{x,y}])=>{
          const {cx,cy}=w2s(x,y); const col=getColor(key);
          const isHov=hover?.key===key&&hover?.kind==='mass';
          const isPop=popup?.key===key;
          const h=iSz/2;
          return <g key={key} opacity={0.95}>
            {col&&<circle cx={cx} cy={cy} r={h+4} fill={col} opacity={0.3}/>}
            <circle cx={cx} cy={cy} r={h+3} fill="none"
              stroke={isPop?'#ff8c00':isHov?'#ffffff':col||'rgba(100,181,246,0.5)'}
              strokeWidth={isPop||isHov?2:1}/>
            <image href={ICON_MASS} x={cx-h} y={cy-h} width={iSz} height={iSz} style={{imageRendering:'pixelated'}}/>
            {camera.zoom>2.8&&<text x={cx} y={cy-h-5} textAnchor="middle" fill="#c9d1d9" fontSize={8} fontFamily="monospace">{key.padStart(2,'0')}</text>}
          </g>;
        })}

        {/* Hydro markers */}
        {Object.entries(parsed.hydro).map(([key,{x,y}])=>{
          const {cx,cy}=w2s(x,y); const col=getColor(key);
          const isHov=hover?.key===key&&hover?.kind==='hydro';
          const isPop=popup?.key===key;
          const h=iSz/2;
          return <g key={key} opacity={0.95}>
            {col&&<circle cx={cx} cy={cy} r={h+4} fill={col} opacity={0.3}/>}
            <rect x={cx-h-3} y={cy-h-3} width={iSz+6} height={iSz+6} rx={2} fill="none"
              stroke={isPop?'#ff8c00':isHov?'#ffffff':col||'rgba(129,199,132,0.5)'}
              strokeWidth={isPop||isHov?2:1}/>
            <image href={ICON_ENERGY} x={cx-h} y={cy-h} width={iSz} height={iSz} style={{imageRendering:'pixelated'}}/>
            {camera.zoom>2.8&&<text x={cx} y={cy-h-5} textAnchor="middle" fill="#c9d1d9" fontSize={8} fontFamily="monospace">H{key}</text>}
          </g>;
        })}

        {/* Army markers */}
        {Object.entries(parsed.armies).map(([army,{x,y}])=>{
          const {cx,cy}=w2s(x,y);
          const idx=parseInt(army.replace('ARMY_',''))-1;
          const col=armyColors[idx%armyColors.length];
          return <g key={army}>
            <circle cx={cx} cy={cy} r={armR+3} fill={col} opacity={0.2}/>
            <circle cx={cx} cy={cy} r={armR+3} fill="none" stroke={col} strokeWidth={1.5} opacity={0.6}/>
            <image href={getAcuIcon(idx)} x={cx-armR} y={cy-armR} width={armR*2} height={armR*2}
              style={{imageRendering:'pixelated'}}/>
            <text x={cx} y={cy+armR+11} textAnchor="middle" fill={col}
              fontSize={Math.max(8,armR*0.6)} fontWeight="700" fontFamily="monospace">{army}</text>
          </g>;
        })}

        {/* Hover tooltip */}
        {hover&&!popup&&(()=>{
          const {cx,cy}=w2s(hover.x,hover.y);
          const a=assignments[hover.key];
          const label=hover.kind==='mass'?`Mass ${hover.key}`:`Hydro ${hover.key}`;
          const sub=a?(a.army||a.type||'assigned'):'click to assign';
          return <g>
            <rect x={cx+14} y={cy-26} width={152} height={36} rx={2} fill="#0a0a0a" stroke="rgba(255,140,0,0.3)" strokeWidth={1}/>
            <text x={cx+20} y={cy-11} fill="#e6edf3" fontSize={11} fontFamily="monospace">{label}</text>
            <text x={cx+20} y={cy+4}  fill="#888"    fontSize={9}  fontFamily="monospace">{sub}</text>
          </g>;
        })()}
      </svg>

      {/* Assignment popup */}
      {popup&&(
        <AssignPopup
          popup={popup}
          current={assignments[popup.key]}
          armyList={armyList}
          armyColors={armyColors}
          containerSize={size}
          onAssign={(type,army,group)=>{
            const asgn = army ? {type,army} : {type,group};
            onAssign(popup.key, asgn);
            if (popup.mirrorMode && army) {
              const mirrorKey = findMirror(popup.key, popup.kind);
              if (mirrorKey) onAssign(mirrorKey, asgn);
            }
            setPopup(null);
          }}
          onRemove={()=>{ onRemove(popup.key); setPopup(null); }}
          onClose={()=>setPopup(null)}
        />
      )}

      {/* Zoom controls */}
      <div className="amh-zoom-controls">
        {[{l:'+',fn:()=>setCamera(c=>({...c,zoom:Math.min(10,c.zoom*1.3)}))},
          {l:'⊙',fn:()=>setCamera({x:0,y:0,zoom:1})},
          {l:'−',fn:()=>setCamera(c=>({...c,zoom:Math.max(0.3,c.zoom*0.77)}))}
        ].map(({l,fn})=>(
          <button key={l} className="amh-zoom-btn" onClick={e=>{e.stopPropagation();fn();}}>{l}</button>
        ))}
      </div>
      <div className="amh-controls-hint">Click → assign &nbsp;·&nbsp; Right-click → clear &nbsp;·&nbsp; Scroll → zoom &nbsp;·&nbsp; Mid/Right-drag → pan</div>
    </div>
  );
}

// ── Assignment Popup ─────────────────────────────────────────────────────────
function AssignPopup({ popup, current, armyList, armyColors, containerSize, onAssign, onRemove, onClose }) {
  useIconsReady();
  const spawnType = popup.kind === 'mass' ? 'spawnMex' : 'spawnHydro';
  const spawnableArmies = armyList.filter(a => a !== 'ARMY_17');

  const PW=220, PH=spawnableArmies.length*34+72;
  let left=popup.sx+18, top=popup.sy-16;
  if (left+PW>containerSize.w-8) left=popup.sx-PW-8;
  if (top+PH>containerSize.h-8) top=containerSize.h-PH-8;
  if (top<8) top=8;

  return (
    <div className="amh-popup" style={{left,top,width:PW}} onClick={e=>e.stopPropagation()}>
      <div className="amh-popup-header">
        <img src={popup.kind==='mass'?ICON_MASS:ICON_ENERGY} alt={popup.kind} className="amh-popup-hicon"/>
        <span className="amh-popup-htitle">{popup.kind==='mass'?`Mass ${popup.key}`:`Hydro ${popup.key}`}</span>
        {popup.mirrorMode&&<span className="amh-popup-mirror-badge">⇌</span>}
        <button className="amh-popup-close" onClick={onClose}>×</button>
      </div>
      <div className="amh-popup-body">
        <div className="amh-popup-army-list">
          {spawnableArmies.map(army=>{
            const idx=parseInt(army.replace('ARMY_',''))-1;
            const col=armyColors[idx%armyColors.length];
            const active=current?.type===spawnType&&current?.army===army;
            return (
              <button key={army} className={`amh-popup-army-btn${active?' active':''}`}
                style={{'--army-color':col}}
                onClick={()=>onAssign(spawnType,army,undefined)}>
                <img src={getAcuIcon(idx)} alt="" style={{width:14,height:14,imageRendering:'pixelated'}}/>
                <span style={{flex:1}}>{army}</span>
                {active&&<span style={{color:col}}>✓</span>}
              </button>
            );
          })}
        </div>
      </div>
      {current&&(
        <button className="amh-popup-remove" onClick={onRemove}>✕ Remove</button>
      )}
    </div>
  );
}
// ── AMH Help Modal — uses shared.css classes throughout ─────────────────────
