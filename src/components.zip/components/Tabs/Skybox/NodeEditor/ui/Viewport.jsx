import React, { useRef, useState, useEffect } from 'react';

/**
 * Viewport — the rendered-output pane (top half).
 *
 * Wraps the <canvas> the parent blits the evaluated texture into. Supports the
 * same navigation as the node graph: mouse-wheel zoom toward the cursor and
 * drag-to-pan, double-click to reset. The backing store matches the graph
 * canvas resolution; the transform only scales the display, so the preview
 * stays crisp when you zoom in on small (256×16) outputs.
 */
const ZOOM_MIN = 0.1;
const ZOOM_MAX = 16;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

const Viewport = React.forwardRef(function Viewport({ w, h, status }, ref) {
  const stageRef = useRef(null);
  const [view, setView] = useState({ x: 0, y: 0, zoom: 1 });
  const viewRef = useRef(view);
  viewRef.current = view;

  useEffect(() => {
    const el = stageRef.current;
    const onWheel = (e) => {
      e.preventDefault();
      const r = el.getBoundingClientRect();
      const cx = e.clientX - r.left - r.width / 2;
      const cy = e.clientY - r.top - r.height / 2;
      setView(v => {
        const zoom = clamp(v.zoom * (e.deltaY < 0 ? 1.15 : 1 / 1.15), ZOOM_MIN, ZOOM_MAX);
        const k = zoom / v.zoom;
        return { zoom, x: cx - (cx - v.x) * k, y: cy - (cy - v.y) * k };
      });
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);

  const startPan = (e) => {
    if (e.button !== 0) return;
    const v = viewRef.current;
    const start = { x: e.clientX - v.x, y: e.clientY - v.y };
    const move = (ev) => setView(cur => ({ ...cur, x: ev.clientX - start.x, y: ev.clientY - start.y }));
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  return (
    <div className="ne-viewport">
      <div
        ref={stageRef}
        className="ne-viewport-stage"
        onPointerDown={startPan}
        onDoubleClick={() => setView({ x: 0, y: 0, zoom: 1 })}
      >
        <canvas
          ref={ref} width={w} height={h} className="ne-viewport-canvas"
          style={{ transform: `translate(${view.x}px, ${view.y}px) scale(${view.zoom})` }}
        />
      </div>
      <div className="ne-viewport-bar">
        <span className="ne-viewport-dim">{w} × {h}</span>
        <span className="ne-viewport-zoom">{Math.round(view.zoom * 100)}%</span>
        {status && <span className="ne-viewport-status">{status}</span>}
      </div>
    </div>
  );
});

export default Viewport;
