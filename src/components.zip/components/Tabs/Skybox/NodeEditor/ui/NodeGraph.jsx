import React, { useRef, useState, useEffect, useCallback } from 'react';
import { getNodeDef, nodeColor } from '../engine/registry.js';

/** Structural equality for an edge (matches disconnect's key fields). */
export function edgeEq(a, b) {
  return !!a && !!b &&
    a.from[0] === b.from[0] && a.from[1] === b.from[1] &&
    a.to[0] === b.to[0] && a.to[1] === b.to[1];
}

/**
 * NodeGraph — the lightweight node canvas (bottom half of the editor).
 *
 * Blender/Gaea-style interaction: drag from a socket and release over the
 * opposite kind of socket (or just over the target node) to connect; the mouse
 * wheel zooms toward the cursor; dragging a header moves a node; middle-mouse
 * drag on empty space pans (left click there just deselects); double-click
 * empty space resets the view. All mutations are
 * lifted to the parent as pure graph edits (docs/NODE_EDITOR_PLAN.md §1) — this
 * component holds only view state (pan + zoom, the in-progress connection).
 *
 * Socket positions use fixed card geometry so edge curves are deterministic
 * without DOM measurement; drop targets resolve from data-attributes via
 * elementFromPoint, with a forgiving fallback that snaps to a node's free
 * socket when you release near the node rather than exactly on the dot. The
 * socket hit area is enlarged in CSS so a connection drag never slips through
 * to a background pan.
 */

const CARD_W = 176;
const HEADER_H = 30;
const SOCKET_ROW = 24;
const BODY_PAD = 8;
const ZOOM_MIN = 0.25;
const ZOOM_MAX = 3;

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

function cardHeight(def) {
  return HEADER_H + BODY_PAD + Math.max(1, def.inputs.length) * SOCKET_ROW + BODY_PAD;
}
function outSocketPos(node) {
  return { x: node.pos[0] + CARD_W, y: node.pos[1] + HEADER_H / 2 };
}
function inSocketPos(node, index) {
  return { x: node.pos[0], y: node.pos[1] + HEADER_H + BODY_PAD + SOCKET_ROW * (index + 0.5) };
}
function edgePath(a, b) {
  const dx = Math.max(30, Math.abs(b.x - a.x) * 0.5);
  return `M ${a.x} ${a.y} C ${a.x + dx} ${a.y}, ${b.x - dx} ${b.y}, ${b.x} ${b.y}`;
}

export default function NodeGraph({ graph, selectedId, selectedEdge, onSelect, onSelectEdge, onMoveNode, onRemoveNode, onConnect, onDisconnect }) {
  const rootRef = useRef(null);
  const [view, setView] = useState({ x: 0, y: 0, zoom: 1 });
  const [conn, setConn] = useState(null); // { from:{id,socket,dir}, start:{x,y}, cursor:{x,y} }
  const viewRef = useRef(view);
  viewRef.current = view;

  const toGraphCoords = (clientX, clientY) => {
    const r = rootRef.current.getBoundingClientRect();
    const v = viewRef.current;
    return { x: (clientX - r.left - v.x) / v.zoom, y: (clientY - r.top - v.y) / v.zoom };
  };

  // ── Wheel zoom (toward cursor) — native non-passive so preventDefault works ─
  useEffect(() => {
    const el = rootRef.current;
    const onWheel = (e) => {
      e.preventDefault();
      const r = el.getBoundingClientRect();
      const cx = e.clientX - r.left, cy = e.clientY - r.top;
      setView(v => {
        const zoom = clamp(v.zoom * (e.deltaY < 0 ? 1.12 : 1 / 1.12), ZOOM_MIN, ZOOM_MAX);
        const k = zoom / v.zoom;
        return { zoom, x: cx - (cx - v.x) * k, y: cy - (cy - v.y) * k };
      });
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);

  // ── Pan the canvas — middle-mouse drag (left click is reserved for
  // selection, so it can deselect on empty space without also panning) ──────
  const onCanvasPointerDown = (e) => {
    if (e.button === 0) { onSelect(null); return; }
    if (e.button !== 1) return;
    e.preventDefault(); // suppress the browser's middle-click autoscroll icon
    const v = viewRef.current;
    const start = { x: e.clientX - v.x, y: e.clientY - v.y };
    const move = (ev) => setView(cur => ({ ...cur, x: ev.clientX - start.x, y: ev.clientY - start.y }));
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  // ── Drag a node by its header ──────────────────────────────────────────────
  const startNodeDrag = (id) => (e) => {
    e.stopPropagation();
    if (e.button !== 0) return;
    onSelect(id);
    const node = graph.nodes[id];
    const origin = { x: node.pos[0], y: node.pos[1] };
    const startClient = { x: e.clientX, y: e.clientY };
    const move = (ev) => {
      const z = viewRef.current.zoom;
      onMoveNode(id, [origin.x + (ev.clientX - startClient.x) / z, origin.y + (ev.clientY - startClient.y) / z]);
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  // ── Drag-to-connect ────────────────────────────────────────────────────────
  const startConnect = (id, socket, dir) => (e) => {
    e.stopPropagation();
    e.preventDefault();
    if (e.button !== 0) return;
    onSelect(id);
    const node = graph.nodes[id];
    const def = getNodeDef(node.type);
    const start = dir === 'out'
      ? outSocketPos(node)
      : inSocketPos(node, Math.max(0, def.inputs.findIndex(s => s.name === socket)));

    setConn({ from: { id, socket, dir }, start, cursor: start });

    const move = (ev) => setConn(c => (c ? { ...c, cursor: toGraphCoords(ev.clientX, ev.clientY) } : c));
    const up = (ev) => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      resolveDrop(ev.clientX, ev.clientY, { id, socket, dir });
      setConn(null);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  const resolveDrop = (clientX, clientY, from) => {
    const el = document.elementFromPoint(clientX, clientY);
    if (!el) return;

    // 1. Released precisely on a socket of the opposite direction.
    const socketEl = el.closest('[data-socket-dir]');
    if (socketEl) {
      const t = { id: socketEl.dataset.nodeId, socket: socketEl.dataset.socketName, dir: socketEl.dataset.socketDir };
      if (t.id !== from.id && t.dir !== from.dir) return commit(from, t);
    }
    // 2. Forgiving fallback: released over a node card — snap to a free socket.
    const cardEl = el.closest('[data-node-card]');
    if (cardEl) {
      const nodeId = cardEl.dataset.nodeCard;
      if (nodeId === from.id) return;
      const def = getNodeDef(graph.nodes[nodeId].type);
      if (from.dir === 'out' && def.inputs.length) return commit(from, { id: nodeId, socket: def.inputs[0].name, dir: 'in' });
      if (from.dir === 'in' && def.outputs.length) return commit(from, { id: nodeId, socket: def.outputs[0].name, dir: 'out' });
    }
  };

  const commit = (from, to) => {
    if (from.dir === 'out') onConnect([from.id, from.socket], [to.id, to.socket]);
    else onConnect([to.id, to.socket], [from.id, from.socket]);
  };

  const resetView = useCallback(() => setView({ x: 0, y: 0, zoom: 1 }), []);
  const ids = Object.keys(graph.nodes);

  return (
    <div
      ref={rootRef}
      className={`ne-graph${conn ? ' is-connecting' : ''}`}
      onPointerDown={onCanvasPointerDown}
      onDoubleClick={resetView}
      onContextMenu={(e) => { e.preventDefault(); setConn(null); }}
    >
      <div
        className="ne-graph-inner"
        style={{ transform: `translate(${view.x}px, ${view.y}px) scale(${view.zoom})` }}
      >
        <svg className="ne-edges" width="100%" height="100%" style={{ overflow: 'visible' }}>
          {graph.edges.map((edge, i) => {
            const fromNode = graph.nodes[edge.from[0]];
            const toNode = graph.nodes[edge.to[0]];
            if (!fromNode || !toNode) return null;
            const toDef = getNodeDef(toNode.type);
            const idx = Math.max(0, toDef.inputs.findIndex(s => s.name === edge.to[1]));
            const sel = edgeEq(edge, selectedEdge);
            return (
              <path
                key={i} className={`ne-edge${sel ? ' is-sel' : ''}`} d={edgePath(outSocketPos(fromNode), inSocketPos(toNode, idx))}
                onPointerDown={(e) => { if (e.button !== 0) return; e.stopPropagation(); onSelectEdge(edge); }}
              >
                <title>Click to select · Delete to remove</title>
              </path>
            );
          })}
          {conn && <path className="ne-edge ne-edge-pending" d={edgePath(conn.start, conn.cursor)} />}
        </svg>

        {ids.map((id) => {
          const node = graph.nodes[id];
          const def = getNodeDef(node.type);
          const h = cardHeight(def);
          const selected = id === selectedId;
          const accent = nodeColor(def);
          return (
            <div
              key={id}
              data-node-card={id}
              className={`ne-node${selected ? ' is-sel' : ''}`}
              style={{ left: node.pos[0], top: node.pos[1], width: CARD_W, minHeight: h, '--node-accent': accent }}
              onPointerDown={(e) => { e.stopPropagation(); onSelect(id); }}
            >
              <div className="ne-node-head" onPointerDown={startNodeDrag(id)}>
                <span className="ne-dot" style={{ background: accent }} />
                <span className="ne-node-label">{def.label}</span>
                <button
                  className="ne-node-del" title="Delete node"
                  onPointerDown={(e) => { e.stopPropagation(); onRemoveNode(id); }}
                >×</button>
              </div>

              <div className="ne-node-body">
                {def.inputs.map((s) => (
                  <div key={s.name} className="ne-socket-row">
                    <span
                      className="ne-socket ne-socket-in"
                      data-socket-dir="in" data-node-id={id} data-socket-name={s.name}
                      onPointerDown={startConnect(id, s.name, 'in')}
                      title={`input: ${s.name}`}
                    />
                    <span className="ne-socket-label">{s.name}</span>
                  </div>
                ))}
                {def.inputs.length === 0 && <div className="ne-socket-row ne-socket-none">source</div>}
              </div>

              {def.outputs.length > 0 && (
                <span
                  className={`ne-socket ne-socket-out${conn?.from.id === id ? ' is-armed' : ''}`}
                  style={{ top: HEADER_H / 2 }}
                  data-socket-dir="out" data-node-id={id} data-socket-name={def.outputs[0].name}
                  onPointerDown={startConnect(id, def.outputs[0].name, 'out')}
                  title="output — drag to an input"
                />
              )}
            </div>
          );
        })}
      </div>

      <div className="ne-zoom-badge" title="Scroll to zoom · middle-drag to pan · double-click to reset">{Math.round(view.zoom * 100)}%</div>
      {conn && <div className="ne-graph-hint">Release over an input socket (or the target node) to connect</div>}
    </div>
  );
}
