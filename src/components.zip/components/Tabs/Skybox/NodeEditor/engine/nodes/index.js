/**
 * nodes/index.js — registers every built-in node type.
 *
 * Importing this module for its side effects populates the registry. Adding a
 * new node is: create the file, register itself, add one import line here.
 * (This is the whole "new nodes extend nothing, they register" story from
 * docs/NODE_EDITOR_PLAN.md §4.)
 */

import './solidColor.js';
import './noise.js';
import './skyGradient.js';
import './gradient.js';
import './levels.js';
import './curves.js';
import './hsv.js';
import './invert.js';
import './clamp.js';
import './blur.js';
import './transform.js';
import './tile.js';
import './alphaRamp.js';
import './blend.js';
import './channelCombine.js';
import './output.js';
