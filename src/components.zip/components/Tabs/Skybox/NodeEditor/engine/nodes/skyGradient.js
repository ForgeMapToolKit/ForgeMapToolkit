/**
 * skyGradient.js — vertical sky backdrop for an EnvCube (docs NODE_EDITOR_PLAN §8.1).
 *
 * A Source (no inputs): a horizon→mid→zenith vertical gradient, the base layer
 * a reflection is composited onto. Colours are editable directly, and a
 * `readScmap` flag + `path` mark the intended "pull the sky straight out of the
 * .scmap" workflow — that read needs a new scmap skybox-block parser over IPC
 * (not yet built; there's no such handler in electron/modules/scmap.js today),
 * so for now the node always renders from its own colour params and the flag is
 * the wired-up placeholder. See the plan's open question §14.4.
 */

import { registerNode } from '../registry.js';
import { hexToRgb } from '../colorUtil.js';

const FRAG = `#version 300 es
precision highp float;
in vec2 v_uv;
out vec4 fragColor;
uniform vec3  u_horizon, u_mid, u_zenith;
uniform float u_midPos;
void main() {
  float v = v_uv.y;                     // 0 = bottom (horizon), 1 = top (zenith)
  vec3 col = v < u_midPos
    ? mix(u_horizon, u_mid, v / max(u_midPos, 1e-4))
    : mix(u_mid, u_zenith, (v - u_midPos) / max(1.0 - u_midPos, 1e-4));
  fragColor = vec4(col, 1.0);
}`;

registerNode({
  type: 'sky-gradient',
  category: 'source',
  label: 'Sky Gradient',
  accent: '#5ec8ff',
  params: {
    horizon:   { type: 'color', label: 'Horizon', default: '#88aacc' },
    mid:       { type: 'color', label: 'Mid', default: '#446699' },
    zenith:    { type: 'color', label: 'Zenith', default: '#0a1a3a' },
    midPos:    { type: 'f', label: 'Mid height', default: 0.5, min: 0, max: 1, step: 0.01 },
    readScmap: { type: 'b', label: 'Read from .scmap', default: false },
    path:      { type: 'text', label: '.scmap path', default: '' },
  },
  inputs: [],
  render(ctx, { params, target }) {
    const c = (hex) => hexToRgb(hex);
    ctx.pass(ctx.program(FRAG), {
      target,
      uniforms: {
        u_horizon: { type: 'v3', value: c(params.horizon) },
        u_mid:     { type: 'v3', value: c(params.mid) },
        u_zenith:  { type: 'v3', value: c(params.zenith) },
        u_midPos:  { type: 'f', value: params.midPos ?? 0.5 },
      },
    });
  },
});
