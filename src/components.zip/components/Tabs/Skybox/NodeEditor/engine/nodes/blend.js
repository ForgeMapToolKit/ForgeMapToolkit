/**
 * blend.js — the layer-composer (docs/NODE_EDITOR_PLAN.md §5.2).
 *
 * Two inputs — `base` (u_in0) and `over` (u_in1) — composited with a blend
 * mode and an opacity. This is the graph's central compositor: instead of
 * threading blend/opacity across scattered edges, every layer flows through a
 * Blend node. `over`'s own alpha modulates the mix, so a sprite with a cut-out
 * alpha lands on the base cleanly.
 *
 * If only `base` is wired it passes through; if only `over` is wired it shows
 * over on transparent. Missing both → cleared target.
 */

import { registerNode } from '../registry.js';

const MODES = ['Normal', 'Add', 'Multiply', 'Screen', 'Overlay', 'Lighten', 'Darken'];

const FRAG = `#version 300 es
precision highp float;
in vec2 v_uv;
out vec4 fragColor;
uniform sampler2D u_in0; // base
uniform sampler2D u_in1; // over
uniform int   u_mode;
uniform float u_opacity;
uniform int   u_hasBase;
uniform int   u_hasOver;

vec3 blend(vec3 b, vec3 o, int m) {
  if (m == 1) return b + o;                          // add
  if (m == 2) return b * o;                          // multiply
  if (m == 3) return 1.0 - (1.0 - b) * (1.0 - o);    // screen
  if (m == 4) return mix(2.0*b*o, 1.0 - 2.0*(1.0-b)*(1.0-o), step(0.5, b)); // overlay
  if (m == 5) return max(b, o);                      // lighten
  if (m == 6) return min(b, o);                      // darken
  return o;                                          // normal
}

void main() {
  vec4 base = u_hasBase == 1 ? texture(u_in0, v_uv) : vec4(0.0);
  if (u_hasOver == 0) { fragColor = base; return; }
  vec4 over = texture(u_in1, v_uv);
  float a = over.a * u_opacity;
  vec3 rgb = mix(base.rgb, blend(base.rgb, over.rgb, u_mode), a);
  float outA = base.a + a * (1.0 - base.a);          // over-composite alpha
  fragColor = vec4(rgb, outA);
}`;

registerNode({
  type: 'layer-composer',
  category: 'compositor',
  label: 'Blend',
  accent: '#ffb454',
  params: {
    mode:    { type: 'select', label: 'Blend mode', default: 'Normal', options: MODES },
    opacity: { type: 'f', label: 'Opacity', default: 1, min: 0, max: 1, step: 0.01 },
  },
  inputs: [{ name: 'base' }, { name: 'over' }],
  render(ctx, { params, inputs, target }) {
    if (!inputs[0] && !inputs[1]) return; // nothing wired → leave cleared
    const modeIdx = Math.max(0, MODES.indexOf(params.mode));
    ctx.pass(ctx.program(FRAG), {
      target,
      inputs: [inputs[0] || inputs[1], inputs[1] || inputs[0]],
      uniforms: {
        u_mode:    { type: 'i', value: modeIdx },
        u_opacity: { type: 'f', value: params.opacity ?? 1 },
        u_hasBase: { type: 'i', value: inputs[0] ? 1 : 0 },
        u_hasOver: { type: 'i', value: inputs[1] ? 1 : 0 },
      },
    });
  },
});
