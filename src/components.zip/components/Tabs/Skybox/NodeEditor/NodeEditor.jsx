import React, { useEffect, useMemo, useRef, useState, useCallback, useReducer } from 'react';
import './NodeEditor.css';
import './engine/nodes/index.js'; // side-effect: populate the registry

import { createGLContext } from './engine/glContext.js';
import { createEvaluator } from './engine/evaluator.js';
import { allNodeDefs, getNodeDef, hasNodeDef, categoryColor, CATEGORY_ORDER } from './engine/registry.js';
import { addNode, removeNode, setNodeParams, setNodePos, connect, disconnect, findOutput } from './engine/graph.js';
import { MODES, MODE_LIST, DEFAULT_MODE } from './engine/modes.js';
import { exportGraphToDds } from './engine/exportDds.js';

import Viewport from './ui/Viewport.jsx';
import NodeGraph from './ui/NodeGraph.jsx';
import Inspector from './ui/Inspector.jsx';
import NumberField from './ui/NumberField.jsx';

/**
 * NodeEditor — the tab parent (docs/NODE_EDITOR_PLAN.md).
 *
 * Owns the WebGL engine + evaluator (imperative, refs), the .fmtgraph document
 * (React state), and the split-viewport layout. Every edit is a pure graph
 * transform from engine/graph.js; the engine re-evaluates the minimal dirty set
 * and blits the result into the preview canvas.
 *
 * Editor UX beyond render: node + link selection with keyboard delete, JSON
 * snapshot undo/redo (continuous gestures like a slider- or node-drag coalesce
 * into one step via a tag+time key), and a Tab-triggered add-node search — all
 * on the same "document is the truth" model, so undo is just swapping the JSON.
 */
const NodeEditor = ({ settings }) => {
  const [graph, setGraphState] = useState(() => MODES[DEFAULT_MODE].makeGraph());
  const [selectedId, setSelectedId] = useState(null);
  const [selectedEdge, setSelectedEdge] = useState(null);
  const [status, setStatus] = useState('');
  const [glError, setGlError] = useState(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const canvasRef = useRef(null);
  const ctxRef = useRef(null);
  const evalRef = useRef(null);
  const searchInputRef = useRef(null);
  const fileInputRef = useRef(null);

  // ── Undo/redo: JSON snapshots with gesture coalescing ─────────────────────
  const pastRef = useRef([]);
  const futureRef = useRef([]);
  const tagRef = useRef(null);
  const timeRef = useRef(0);
  const [, bumpHist] = useReducer(x => x + 1, 0);

  /** History-aware graph committer. `tag` groups a continuous gesture (drag a
   *  slider / a node) into a single undo step; pass null for discrete edits. */
  const setGraph = useCallback((updater, tag = null) => {
    setGraphState(prev => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      if (next === prev) return prev;
      const now = Date.now();
      const coalesce = !!tag && tag === tagRef.current && (now - timeRef.current) < 600;
      if (!coalesce) {
        pastRef.current.push(prev);
        if (pastRef.current.length > 120) pastRef.current.shift();
        futureRef.current = [];
      }
      tagRef.current = tag;
      timeRef.current = now;
      return next;
    });
    bumpHist();
  }, []);

  const undo = useCallback(() => {
    if (!pastRef.current.length) return;
    setGraphState(prev => {
      futureRef.current.push(prev);
      const restored = pastRef.current.pop();
      tagRef.current = null;
      return restored;
    });
    setSelectedId(null); setSelectedEdge(null);
    bumpHist();
  }, []);

  const redo = useCallback(() => {
    if (!futureRef.current.length) return;
    setGraphState(prev => {
      pastRef.current.push(prev);
      const restored = futureRef.current.pop();
      tagRef.current = null;
      return restored;
    });
    setSelectedId(null); setSelectedEdge(null);
    bumpHist();
  }, []);

  // ── Engine lifecycle ────────────────────────────────────────────────────
  useEffect(() => {
    try {
      const ctx = createGLContext();
      ctxRef.current = ctx;
      evalRef.current = createEvaluator(ctx);
    } catch (err) {
      setGlError(err.message);
    }
    return () => {
      evalRef.current?.dispose();
      ctxRef.current?.dispose();
      evalRef.current = null;
      ctxRef.current = null;
    };
  }, []);

  // Root shown in the preview: the selected node if any, else the output node.
  const previewRoot = useMemo(
    () => (selectedId && graph.nodes[selectedId] ? selectedId : findOutput(graph)),
    [selectedId, graph],
  );

  // ── Re-evaluate + blit whenever the document or preview root changes ──────
  useEffect(() => {
    const ctx = ctxRef.current, ev = evalRef.current, canvas = canvasRef.current;
    if (!ctx || !ev || !canvas || !previewRoot) return;
    let raf = requestAnimationFrame(() => {
      try {
        const target = ev.evaluate(graph, previewRoot);
        if (target) {
          ctx.blitToCanvas(target.tex, canvas);
          setStatus('');
        }
      } catch (err) {
        setStatus(`⚠ ${err.message}`);
      }
    });
    return () => cancelAnimationFrame(raf);
  }, [graph, previewRoot]);

  // ── Graph edits (all pure; tags group drags into single undo steps) ───────
  const onParams = useCallback((id, patch) => {
    setGraph(g => setNodeParams(g, id, patch), `param:${id}:${Object.keys(patch).join(',')}`);
  }, [setGraph]);
  const onMoveNode = useCallback((id, pos) => setGraph(g => setNodePos(g, id, pos), `move:${id}`), [setGraph]);
  const onConnect = useCallback((from, to) => setGraph(g => connect(g, from, to)), [setGraph]);
  const onDisconnect = useCallback((edge) => setGraph(g => disconnect(g, edge)), [setGraph]);
  const onRemoveNode = useCallback((id) => {
    setGraph(g => removeNode(g, id));
    setSelectedId(s => (s === id ? null : s));
  }, [setGraph]);

  const onAddNode = useCallback((type) => {
    setGraph(g => {
      const { graph: ng, id } = addNode(g, type, [40 + Math.random() * 60, 210 + Math.random() * 60]);
      queueMicrotask(() => { setSelectedId(id); setSelectedEdge(null); });
      return ng;
    });
  }, [setGraph]);

  // Selecting a node clears an edge selection and vice-versa.
  const handleSelectNode = useCallback((id) => { setSelectedId(id); setSelectedEdge(null); }, []);
  const handleSelectEdge = useCallback((edge) => { setSelectedEdge(edge); setSelectedId(null); }, []);

  const onPickMode = (key) => {
    setGraph(() => MODES[key].makeGraph());
    setSelectedId(null); setSelectedEdge(null); setStatus('');
  };

  const setCanvasSize = (dim, value) => {
    const v = Math.max(1, Math.min(4096, Math.round(Number(value) || 1)));
    setGraph(g => ({ ...g, canvas: { ...g.canvas, [dim]: v } }), `canvas:${dim}`);
  };

  // ── Palette (filtered by the graph's mode template) ───────────────────────
  const palette = useMemo(() => {
    const allowed = MODES[graph.mode]?.palette;
    const defs = allNodeDefs().filter(d => (allowed ? allowed.includes(d.type) : true));
    return CATEGORY_ORDER.map(cat => ({ cat, defs: defs.filter(d => d.category === cat) })).filter(g => g.defs.length);
  }, [graph.mode]);

  const searchResults = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const flat = palette.flatMap(g => g.defs);
    return q ? flat.filter(d => d.label.toLowerCase().includes(q) || d.type.includes(q)) : flat;
  }, [palette, searchQuery]);

  const addFromSearch = useCallback((type) => { onAddNode(type); setSearchOpen(false); }, [onAddNode]);

  // ── Global keyboard: Tab search, Delete, Undo/Redo ────────────────────────
  useEffect(() => {
    const onKey = (e) => {
      const t = e.target;
      const inField = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable);

      // Tab opens the add-node search (unless typing in a field).
      if (e.key === 'Tab' && !inField && !searchOpen) {
        e.preventDefault();
        setSearchOpen(true); setSearchQuery('');
        queueMicrotask(() => searchInputRef.current?.focus());
        return;
      }
      if (inField) return; // let form fields keep their own keys (incl. text undo)

      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedEdge) { onDisconnect(selectedEdge); setSelectedEdge(null); e.preventDefault(); }
        else if (selectedId) { onRemoveNode(selectedId); e.preventDefault(); }
        return;
      }
      const mod = e.ctrlKey || e.metaKey;
      if (mod && (e.key === 'z' || e.key === 'Z')) { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
      if (mod && (e.key === 'y' || e.key === 'Y')) { e.preventDefault(); redo(); return; }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selectedId, selectedEdge, searchOpen, onDisconnect, onRemoveNode, undo, redo]);

  // ── Persistence: save/load the .fmtgraph document ────────────────────────
  const onSaveGraph = () => {
    const blob = new Blob([JSON.stringify(graph, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${graph.mode || 'graph'}.fmtgraph`;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
    setStatus('✓ Saved .fmtgraph');
  };

  const onLoadGraphFile = (e) => {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow re-loading the same file
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        if (!parsed || typeof parsed !== 'object' || !parsed.nodes || !parsed.canvas) {
          setStatus('⚠ not a valid .fmtgraph'); return;
        }
        if (!Array.isArray(parsed.edges)) parsed.edges = [];
        const unknown = Object.values(parsed.nodes).find(n => !hasNodeDef(n.type));
        if (unknown) { setStatus(`⚠ unknown node type "${unknown.type}"`); return; }
        setGraph(() => parsed);
        setSelectedId(null); setSelectedEdge(null);
        setStatus('✓ Loaded .fmtgraph');
      } catch (err) { setStatus(`⚠ load failed: ${err.message}`); }
    };
    reader.readAsText(file);
  };

  // ── Export ────────────────────────────────────────────────────────────────
  const onExport = async () => {
    const outputId = findOutput(graph);
    if (!outputId) { setStatus('⚠ no output node in the graph'); return; }
    setStatus('Selecting folder…');
    const defaultPath = (settings?.mapsFolder || '').trim() || undefined;
    let res;
    try {
      res = await window.electronAPI.invoke('settings-pick-folder', { title: 'Export DDS to folder', defaultPath });
    } catch { setStatus('⚠ folder picker unavailable'); return; }
    if (!res?.success || !res.path) { setStatus(''); return; }

    setStatus('Rendering + encoding…');
    try {
      const out = await exportGraphToDds({
        ctx: ctxRef.current, evaluator: evalRef.current, graph, outputId, dir: res.path,
      });
      setStatus(out.success ? `✓ Exported ${out.path} (${(out.bytes / 1024).toFixed(1)} KB)` : `⚠ ${out.error}`);
    } catch (err) {
      setStatus(`⚠ ${err.message}`);
    }
  };

  if (glError) {
    return (
      <div className="node-editor-tab">
        <div className="ne-fatal">WebGL2 is required for the Node Editor and could not be initialised.<br />{glError}</div>
      </div>
    );
  }

  const canUndo = pastRef.current.length > 0;
  const canRedo = futureRef.current.length > 0;

  return (
    <div className="node-editor-tab">
      {/* Toolbar */}
      <div className="ne-toolbar">
        <label className="ne-tool-group">
          <span className="ne-tool-label">Asset</span>
          <select value={graph.mode} onChange={e => onPickMode(e.target.value)}>
            {MODE_LIST.map(m => <option key={m.key} value={m.key}>{m.label}</option>)}
          </select>
        </label>
        <div className="ne-tool-group">
          <span className="ne-tool-label">Canvas</span>
          <NumberField min={1} max={4096} value={graph.canvas.w} onChange={v => setCanvasSize('w', v)} />
          <span className="ne-tool-x">×</span>
          <NumberField min={1} max={4096} value={graph.canvas.h} onChange={v => setCanvasSize('h', v)} />
        </div>
        <div className="ne-tool-group ne-tool-hist">
          <button className="ne-btn ne-btn-icon" onClick={undo} disabled={!canUndo} title="Undo (Ctrl+Z)">↶</button>
          <button className="ne-btn ne-btn-icon" onClick={redo} disabled={!canRedo} title="Redo (Ctrl+Shift+Z)">↷</button>
        </div>
        <div className="ne-tool-spacer" />
        <div className="ne-tool-group ne-tool-hist">
          <button className="ne-btn ne-btn-mini" onClick={onSaveGraph} title="Download the graph as a .fmtgraph file">Save</button>
          <button className="ne-btn ne-btn-mini" onClick={() => fileInputRef.current?.click()} title="Load a .fmtgraph file">Load</button>
          <input
            ref={fileInputRef} type="file" accept=".fmtgraph,.json,application/json"
            style={{ display: 'none' }} onChange={onLoadGraphFile}
          />
        </div>
        <button className="ne-btn ne-btn-primary" onClick={onExport}>Export DDS</button>
      </div>

      {/* Gaea-style body: viewport (top) + graph (bottom) span the full width;
          the Toolbox docks left inside the graph, Properties right full-height. */}
      <div className="ne-body">
        <div className="ne-stage-left">
          <Viewport ref={canvasRef} w={graph.canvas.w} h={graph.canvas.h} status={status} />

          <div className="ne-graph-zone">
            <NodeGraph
              graph={graph}
              selectedId={selectedId}
              selectedEdge={selectedEdge}
              onSelect={handleSelectNode}
              onSelectEdge={handleSelectEdge}
              onMoveNode={onMoveNode}
              onRemoveNode={onRemoveNode}
              onConnect={onConnect}
              onDisconnect={onDisconnect}
            />

            <div className="ne-palette-dock">
              <div className="ne-panel-title">Toolbox</div>
              {palette.map(({ cat, defs }) => (
                <div key={cat} className="ne-palette-cat">
                  <div className="ne-palette-cat-label" style={{ color: categoryColor(cat) }}>{cat}</div>
                  <div className="ne-palette-items">
                    {defs.map(d => (
                      <button key={d.type} className="ne-palette-item" onClick={() => onAddNode(d.type)}>
                        <span className="ne-dot" style={{ background: categoryColor(d.category) }} />
                        {d.label}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
              <div className="ne-palette-hint">Tab to search</div>
            </div>

            {searchOpen && (
              <div className="ne-search" onPointerDown={e => e.stopPropagation()}>
                <input
                  ref={searchInputRef}
                  className="ne-search-input"
                  placeholder="Search nodes… (Enter to add, Esc to close)"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') { const first = searchResults[0]; if (first) addFromSearch(first.type); }
                    else if (e.key === 'Escape') { e.preventDefault(); setSearchOpen(false); }
                  }}
                />
                <div className="ne-search-list">
                  {searchResults.length === 0 && <div className="ne-search-empty">No matching nodes</div>}
                  {searchResults.map(d => (
                    <button key={d.type} className="ne-search-item" onClick={() => addFromSearch(d.type)}>
                      <span className="ne-dot" style={{ background: categoryColor(d.category) }} />
                      <span className="ne-search-item-label">{d.label}</span>
                      <span className="ne-search-item-cat">{d.category}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="ne-inspector-col">
          <Inspector graph={graph} selectedId={selectedId} onParams={onParams} />
        </div>
      </div>
    </div>
  );
};

export default NodeEditor;
